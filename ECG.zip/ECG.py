import numpy as np
from matplotlib import pyplot as plt

iSampleRate = 2000					# Частота дискретизации, 2000 отсчетов в секунду
x = np.fromfile("ecgsignal.dat",dtype=np.float32)
iSampleCount = x.shape[0]			# Номер образца
t = np.linspace(0,iSampleCount/iSampleRate,iSampleCount)

xFFT = np.abs(np.fft.rfft(x)/iSampleCount)  # Быстрое преобразование Фурье
xFreqs = np.linspace(0, iSampleRate/2, int(iSampleCount/2)+1)

plt.figure(figsize=(10,6))
ax0 = plt.subplot(211)             # Нарисовать сигнал временной области
ax0.set_xlabel("Time(s)")
ax0.set_ylabel("Amp(μV)")
ax0.plot(t,x)

ax1 = plt.subplot(212)             #   сигнал-спектр в частотной области
ax1.set_xlabel("Freq(Hz)")
ax1.set_ylabel("Power")
ax1.plot(xFreqs, xFFT)
plt.show()